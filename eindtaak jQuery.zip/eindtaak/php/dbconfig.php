<?php


class DBConfig {

	//geen instance van deze class wordt aangemaakt, dient enkel als container
	public static $host = "localhost";
	public static $dbUser = "sam";
	public static $dbPassw = "sam123";
	public static $dbName = "airports";


}

?>