<?php
namespace PizzeriaProject\Data;

class DBConfig{ //class om niet telkens de gegevens te moeten invullen bij het aanmaken van een PDO
	public static $DB_CONNSTRING = "mysql:host=localhost;dbname=pizza2";
	public static $DB_USERNAME = "sam";
	public static $DB_PASSWORD = "sam123";
}

